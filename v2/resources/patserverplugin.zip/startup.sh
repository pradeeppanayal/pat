#!/bin/sh 
#Author Pradeep

ps cax | grep server.pyc > /dev/null

if [ $? -eq 0 ]; then
	echo 'PAT Plugin is already running'
else
	chmod +x server.pyc
	#nohup ./server.py &
	(./server.pyc &)
	echo 'PAT Plugin started'
fi
 
