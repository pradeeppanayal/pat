#!/bin/sh 
#Author Pradeep

serverpid=$(ps ax | pgrep server.pyc)
kill -9 $serverpid
#echo 'Server shutdown completed'
